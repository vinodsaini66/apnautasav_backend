# AI Travel Customer Support System

Enterprise-grade AI support bot for travel companies with:
- Website chat
- WhatsApp via Twilio
- LangGraph + LangChain
- MongoDB + Redis
- Ticket escalation
- Multilingual support

## Setup

1. Copy `.env.example` to `.env` and fill values.
2. Install dependencies:

   npm install

3. Start dev server:

   npm run dev

4. For production:

   docker-compose up -d

## WhatsApp Setup (Twilio)

1. Create a Twilio account.
2. Enable WhatsApp sandbox or production number.
3. Set webhook URL:
   POST https://your-domain.com/whatsapp/webhook

## Next Steps

- Ingest your FAQs and policies into the vector store.
- Connect booking database.
- Add CRM / payment tools if needed.
- Customize prompts for brand tone.

Enjoy 🚀
