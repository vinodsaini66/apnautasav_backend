export const sendMessage = async (message: string, sessionId: string) => {
  const res = await fetch("http://localhost:3000/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      message,
      sessionId,
      userId: "web-user"
    })
  });
  return res.json();
};
