import ChatWidget from "../components/ChatWidget";

export default function Home() {
  return (
    <main className="min-h-screen p-8">
      <h1 className="text-2xl font-bold">Travel Website</h1>
      <p>Welcome to our travel booking platform.</p>
      <ChatWidget />
    </main>
  );
}
