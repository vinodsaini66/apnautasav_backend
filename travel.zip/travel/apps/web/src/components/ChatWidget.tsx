"use client";
import { useState } from "react";
import { sendMessage } from "../lib/api";

export default function ChatWidget() {
  const [messages, setMessages] = useState<{ role: string; content: string }[]>([]);
  const [input, setInput] = useState("");
  const sessionId = "web-session-1";

  const handleSend = async () => {
    if (!input.trim()) return;
    const userMsg = { role: "user", content: input };
    setMessages(prev => [...prev, userMsg]);

    const res = await sendMessage(input, sessionId);
    const botMsg = { role: "assistant", content: res.reply };
    setMessages(prev => [...prev, botMsg]);

    setInput("");
  };

  return (
    <div className="fixed bottom-4 right-4 w-80 bg-white shadow-lg rounded-xl p-4">
      <h3 className="font-bold mb-2">Travel Support Chat</h3>
      <div className="h-64 overflow-y-auto border p-2 mb-2">
        {messages.map((m, i) => (
          <div key={i} className={`mb-1 ${m.role === "user" ? "text-right" : "text-left"}`}>
            <span className="text-sm">{m.content}</span>
          </div>
        ))}
      </div>
      <input
        className="border w-full p-1 mb-2"
        value={input}
        onChange={e => setInput(e.target.value)}
        placeholder="Type your message..."
      />
      <button
        className="bg-blue-600 text-white w-full py-1 rounded"
        onClick={handleSend}
      >
        Send
      </button>
    </div>
  );
}
