import { Router } from "express";
import { aiApp, type State } from "@repo/ai-core/src/agent";
import { loadMemory, saveMemory } from "@repo/db/src/redis";
import { logConversation } from "@repo/analytics/src/logger";

const router = Router();

router.post("/", async (req, res) => {
  const { message, sessionId, userId } = req.body;

  const memory = await loadMemory(sessionId);

  const result = (await aiApp.invoke({
    messages: [...memory, { role: "user", content: message }],
    userId,
    sessionId
  })) as State;

  //@ts-ignore
  const reply = result.messages.at(-1)?.content;
  await saveMemory(sessionId, result.messages);
  await logConversation(sessionId, result.messages);

  res.json({ reply });
});

export default router;
