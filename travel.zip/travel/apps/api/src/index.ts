import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import { connectMongo } from "@repo/db/src/mongoose";
import { apiLimiter } from "./middleware/rateLimit";
import chatRoutes from "./routes/chat";
import whatsappRoutes from "./routes/whatsapp";
import { config } from "./config";

const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(apiLimiter);

app.use("/api/chat", chatRoutes);
app.use("/whatsapp", whatsappRoutes);

app.get("/health", (_, res) => res.json({ status: "ok" }));

const start = async () => {
  await connectMongo();
  app.listen(config.port, () => {
    console.log(`🚀 API running on port ${config.port}`);
  });
};

start();
