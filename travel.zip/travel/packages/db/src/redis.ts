import Redis from "ioredis";

export const redis = new Redis(process.env.REDIS_URL!);

export const saveMemory = async (sessionId: string, messages: any[]) => {
  await redis.set(sessionId, JSON.stringify(messages), "EX", 60 * 60 * 24);
};

export const loadMemory = async (sessionId: string) => {
  const data = await redis.get(sessionId);
  return data ? JSON.parse(data) : [];
};
