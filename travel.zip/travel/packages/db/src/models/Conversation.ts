import mongoose from "mongoose";

const ConversationSchema = new mongoose.Schema({
  sessionId: String,
  messages: Array,
  rating: Number,
  createdAt: { type: Date, default: Date.now }
});

export const ConversationModel = mongoose.model("Conversation", ConversationSchema);
