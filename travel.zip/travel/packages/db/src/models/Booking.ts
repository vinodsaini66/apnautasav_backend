import mongoose from "mongoose";

const BookingSchema = new mongoose.Schema({
  bookingId: String,
  customerName: String,
  status: String,
  destination: String,
  travelDate: Date,
  paymentStatus: String
});

export const BookingModel = mongoose.model("Booking", BookingSchema);
