import mongoose from "mongoose";

const TicketSchema = new mongoose.Schema({
  issue: String,
  status: { type: String, default: "open" },
  createdAt: { type: Date, default: Date.now }
});

export const TicketModel = mongoose.model("Ticket", TicketSchema);
