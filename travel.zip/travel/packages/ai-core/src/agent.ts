import { StateGraph } from "@langchain/langgraph";
import { ToolNode } from "@langchain/langgraph/prebuilt";
import { ChatOpenAI } from "@langchain/openai";
import { SYSTEM_PROMPT } from "./prompts";
import { knowledgeTool } from "@repo/tools/src/knowledge.tool";
import { bookingTool } from "@repo/tools/src/booking.tool";
import { ticketTool } from "@repo/tools/src/ticket.tool";
import { languageTool } from "@repo/tools/src/language.tool";
import { z } from "zod";
import "dotenv/config";
// ✅ Define state schema
const StateSchema = z.object({
  messages: z.array(z.any()),
  userId: z.string(),
  sessionId: z.string(),
});

export type State = z.infer<typeof StateSchema>;

const llm = new ChatOpenAI({
  model: "gpt-4o-mini",
  temperature: 0.2,
});

console.log(process.env.OPENAI_API_KEY);

// ✅ Tools must be StructuredTool / RunnableTool
const tools = [knowledgeTool, bookingTool, ticketTool, languageTool];
const toolNode = new ToolNode<State>(tools);

// ✅ Create graph with schema
export const graph = new StateGraph<State>({
  stateSchema: StateSchema,
})
  // ✅ Agent node
  .addNode("agent", async (state: State) => {
    const response = await llm.invoke(
      [
        { role: "system", content: SYSTEM_PROMPT },
        ...state.messages,
      ],
      { tools }
    );

    return {
      messages: [...state.messages, response],
    };
  })
  // ✅ Tool node
  .addNode("tools", toolNode)
  // ✅ Edges
  .addEdge("__start__", "agent")
  .addEdge("agent", "tools")
  .addEdge("tools", "agent");

// ✅ Compile
export const aiApp = graph.compile();
