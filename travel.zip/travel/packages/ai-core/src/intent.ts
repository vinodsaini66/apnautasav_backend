import { ChatOpenAI } from "@langchain/openai";

const llm = new ChatOpenAI({ model: "gpt-4o-mini", temperature: 0 });

export const classifyIntent = async (message: string): Promise<string> => {
  const result = await llm.invoke(
    `Classify this travel query into one of:
booking_status, refund, cancellation, package_info, visa, complaint, general.
Message: ${message}`
  );
  return result.content;
};
