import { ConversationModel } from "@repo/db/src/models/Conversation";

export const logConversation = async (
  sessionId: string,
  messages: any[],
  rating: number | null = null
) => {
  await ConversationModel.create({ sessionId, messages, rating });
};
