import { ChatOpenAI } from "@langchain/openai";
import { tool } from "@langchain/core/tools";
import { z } from "zod";

const llm = new ChatOpenAI({ model: "gpt-4o-mini", temperature: 0 });

export const languageTool = tool(
  async ({ text }: { text: string }) => {
    const result = await llm.invoke(
      `Detect the language and translate this to English if needed:\n${text}`
    );
    return result.content;
  },
  {
    name: "translate_message",
    description: "Detect and translate any language to English",
    schema: z.object({
      text: z.string(),
    }),
  }
);
