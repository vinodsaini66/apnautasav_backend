import { getVectorStore } from "@repo/vector-store/src";
import { tool } from "@langchain/core/tools";
import { z } from "zod";

export const knowledgeTool = tool(
  async ({ query }: { query: string }) => {
    const vectorStore = await getVectorStore();
    const results = await vectorStore.similaritySearch(query, 4);
    return results.map((r) => r.pageContent).join("\n");
  },
  {
    name: "search_knowledge_base",
    description: "Search FAQs, travel policies, packages, SOPs",
    schema: z.object({
      query: z.string(),
    }),
  }
);
