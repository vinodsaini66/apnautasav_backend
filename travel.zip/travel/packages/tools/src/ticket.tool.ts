import { TicketModel } from "@repo/db/src/models/Ticket";
import { tool } from "@langchain/core/tools";
import { z } from "zod";

export const ticketTool = tool(
  async ({ issue }: { issue: string }) => {
    const ticket = await TicketModel.create({ issue, status: "open" });
    return `Ticket created: ${ticket._id}. Our team will contact you shortly.`;
  },
  {
    name: "create_support_ticket",
    description: "Escalate issue to human support team",
    schema: z.object({
      issue: z.string(),
    }),
  }
);
