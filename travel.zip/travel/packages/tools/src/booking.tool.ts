import { BookingModel } from "@repo/db/src/models/Booking";
import { tool } from "@langchain/core/tools";
import { z } from "zod";

export const bookingTool = tool(
  async ({ bookingId }: { bookingId: string }) => {
    const booking = await BookingModel.findOne({ bookingId });
    return booking ? JSON.stringify(booking) : "Booking not found.";
  },
  {
    name: "get_booking_status",
    description: "Get booking details using booking ID",
    schema: z.object({
      bookingId: z.string(),
    }),
  }
);

