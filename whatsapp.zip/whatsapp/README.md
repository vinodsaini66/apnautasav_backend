# 🧠 Tour & Travel AI Customer Support System

Production-grade AI customer support platform for tour & travel companies using Node.js, LangGraph, LangChain, MongoDB, Redis, Twilio WhatsApp, and Docker.

This version contains only backend API and WhatsApp chatbot (no frontend UI).

---

## 🚀 Features

- LangGraph-based AI agent with strict hallucination prevention
- Knowledge base Q&A with embeddings
- Tool calling for bookings, refunds, cancellations, escalation
- Multi-language auto-detection and translation
- Redis session memory + MongoDB long-term memory
- Full conversation analytics and logging
- WhatsApp chatbot via Twilio webhook
- JWT authentication, rate limiting, validation, CORS
- Dockerized production deployment

---

## 🧱 Structure

```
apps/
  api/        # Express backend + WhatsApp webhook
packages/
  ai-core/    # LangGraph agent, prompts, intents
  tools/      # Tool implementations
  db/         # MongoDB + Redis layer
  vector-store/ # Embeddings & retrieval
  analytics/  # Logging & metrics
```

---

## 🐳 Run Locally

```bash
cp .env.example .env
pnpm install
pnpm dev
```

Or with Docker:

```bash
docker-compose up --build
```

---

## 🩺 Health Check

GET /health

---

## 📄 License

MIT