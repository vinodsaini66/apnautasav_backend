import { Router } from "express";
import { AuthRequest } from "../middleware/auth";
import { createTicket, getTickets } from "@db/tickets";

export const ticketRouter = Router();

ticketRouter.get("/", async (req: AuthRequest, res) => {
  const userId = req.user?.id;
  const tickets = await getTickets(userId);
  res.json(tickets);
});

ticketRouter.post("/", async (req: AuthRequest, res) => {
  const userId = req.user?.id;
  const { sessionId, issue } = req.body;

  const ticket = await createTicket({
    userId,
    sessionId,
    issue,
  });

  res.json(ticket);
});