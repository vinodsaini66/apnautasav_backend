import { Router } from "express";
import { z } from "zod";
import { AuthRequest } from "../middleware/auth";
import { saveFeedback } from "@analytics/logger";

export const feedbackRouter = Router();

const feedbackSchema = z.object({
  sessionId: z.string(),
  rating: z.number().min(1).max(5),
  comment: z.string().optional(),
});

feedbackRouter.post("/", async (req: AuthRequest, res) => {
  const parsed = feedbackSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.errors });
  }

  const { sessionId, rating, comment } = parsed.data;
  const userId = req.user?.id;

  await saveFeedback({ userId, sessionId, rating, comment });

  res.json({ success: true });
});