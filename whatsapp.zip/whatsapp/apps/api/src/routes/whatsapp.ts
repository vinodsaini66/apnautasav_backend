import { Router } from "express";
import { processMessage } from "@ai-core/agent";
import { logConversation } from "@analytics/logger";
import { Twilio } from "twilio";

export const whatsappRouter = Router();

const twilioClient = new Twilio(
  process.env.TWILIO_ACCOUNT_SID!,
  process.env.TWILIO_AUTH_TOKEN!
);

whatsappRouter.post("/", async (req, res) => {
  const from = req.body.From;
  const body = req.body.Body;

  const startTime = Date.now();
  const response = await processMessage({
    userId: from,
    sessionId: from,
    message: body,
    channel: "whatsapp",
  });
  const responseTime = Date.now() - startTime;

  await logConversation({
    userId: from,
    sessionId: from,
    channel: "whatsapp",
    userMessage: body,
    aiResponse: response.message,
    intent: response.intent,
    toolsUsed: response.toolsUsed,
    escalated: response.escalated,
    responseTime,
  });

  await twilioClient.messages.create({
    from: process.env.TWILIO_WHATSAPP_NUMBER!,
    to: from,
    body: response.message,
  });

  res.sendStatus(200);
});