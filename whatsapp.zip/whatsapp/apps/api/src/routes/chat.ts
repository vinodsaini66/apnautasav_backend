import { Router } from "express";
import { z } from "zod";
import { AuthRequest } from "../middleware/auth";
import { processMessage } from "@ai-core/agent";
import { logConversation } from "@analytics/logger";

export const chatRouter = Router();

const chatSchema = z.object({
  sessionId: z.string(),
  message: z.string().min(1),
});

chatRouter.post("/", async (req: AuthRequest, res) => {
  const parsed = chatSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.errors });
  }

  const { sessionId, message } = parsed.data;
  const userId = req.user?.id;

  const startTime = Date.now();
  const response = await processMessage({
    userId,
    sessionId,
    message,
    channel: "web",
  });
  const responseTime = Date.now() - startTime;

  await logConversation({
    userId,
    sessionId,
    channel: "web",
    userMessage: message,
    aiResponse: response.message,
    intent: response.intent,
    toolsUsed: response.toolsUsed,
    escalated: response.escalated,
    responseTime,
  });

  res.json(response);
});