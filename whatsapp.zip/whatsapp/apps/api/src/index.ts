import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import dotenv from "dotenv";
import bodyParser from "body-parser";
import rateLimit from "express-rate-limit";
import { connectMongo } from "@db/client";
import { initRedis } from "@db/redis";
import { authMiddleware } from "./middleware/auth";
import { healthRouter } from "./routes/health";
import { chatRouter } from "./routes/chat";
import { whatsappRouter } from "./routes/whatsapp";
import { feedbackRouter } from "./routes/feedback";
import { ticketRouter } from "./routes/tickets";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || "*" }));
app.use(morgan("combined"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const limiter = rateLimit({
  windowMs: Number(process.env.RATE_LIMIT_WINDOW_MS) || 60000,
  max: Number(process.env.RATE_LIMIT_MAX) || 100,
});
app.use(limiter);

app.use("/health", healthRouter);
app.use("/api/chat", authMiddleware, chatRouter);
app.use("/api/feedback", authMiddleware, feedbackRouter);
app.use("/api/tickets", authMiddleware, ticketRouter);
app.use("/webhook/whatsapp", whatsappRouter);

async function startServer() {
  await connectMongo();
  await initRedis();
  app.listen(PORT, () => {
    console.log(`API server running on port ${PORT}`);
  });
}

startServer();