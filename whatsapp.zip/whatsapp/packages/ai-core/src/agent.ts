import { StateGraph, END } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";
import { HumanMessage, SystemMessage } from "@langchain/core/messages";
import {
  knowledgeTool,
  bookingStatusTool,
  refundTool,
  cancellationTool,
  escalationTool,
  detectLanguage,
  translateText,
} from "@tools/core";
import { getRedis } from "@db/client";

const llm = new ChatOpenAI({
  model: "gpt-4o-mini",
  temperature: 0,
  openAIApiKey: process.env.OPENAI_API_KEY,
});

export type AgentInput = {
  userId: string;
  sessionId: string;
  message: string;
  channel: "web" | "whatsapp";
};

export type AgentOutput = {
  message: string;
  intent: string;
  toolsUsed: string[];
  escalated: boolean;
};

type AgentState = {
  input: AgentInput;
  intent?: string;
  response?: string;
  toolsUsed: string[];
  escalated: boolean;
  language?: string;
};

async function detectIntent(state: AgentState): Promise<Partial<AgentState>> {
  const res = await llm.invoke([
    new SystemMessage(`You are an intent classifier for a travel support system.
Allowed intents:
- booking_status
- refund
- cancellation
- package_info
- visa
- complaint
- general_query

Return ONLY the intent label.`),
    new HumanMessage(state.input.message),
  ]);

  const intent = res.content.trim();
  return { intent };
}

async function detectLanguageNode(state: AgentState): Promise<Partial<AgentState>> {
  const lang = await detectLanguage(state.input.message);
  return { language: lang };
}

async function handleIntent(state: AgentState): Promise<Partial<AgentState>> {
  const { intent, input } = state;
  const toolsUsed: string[] = [];

  let response = "";
  let escalated = false;

  try {
    switch (intent) {
      case "booking_status":
        toolsUsed.push("bookingStatusTool");
        response = await bookingStatusTool(input.message);
        break;

      case "refund":
        toolsUsed.push("refundTool");
        response = await refundTool(input.message);
        break;

      case "cancellation":
        toolsUsed.push("cancellationTool");
        response = await cancellationTool(input.message);
        break;

      case "package_info":
      case "visa":
      case "general_query":
        toolsUsed.push("knowledgeTool");
        response = await knowledgeTool(input.message);
        if (!response || response.length < 5) {
          toolsUsed.push("escalationTool");
          response = await escalationTool(input.userId, input.sessionId, input.message);
          escalated = true;
        }
        break;

      case "complaint":
        toolsUsed.push("escalationTool");
        response = await escalationTool(input.userId, input.sessionId, input.message);
        escalated = true;
        break;

      default:
        toolsUsed.push("escalationTool");
        response = await escalationTool(input.userId, input.sessionId, input.message);
        escalated = true;
        break;
    }
  } catch (err) {
    toolsUsed.push("escalationTool");
    response = await escalationTool(input.userId, input.sessionId, input.message);
    escalated = true;
  }

  return { response, toolsUsed, escalated };
}

async function translateResponse(state: AgentState): Promise<Partial<AgentState>> {
  if (state.language && state.language !== "en" && state.response) {
    const translated = await translateText(state.response, state.language);
    return { response: translated };
  }
  return {};
}

async function storeMemory(state: AgentState): Promise<Partial<AgentState>> {
  const redis = getRedis();
  const key = `session:${state.input.sessionId}`;
  const history = await redis.get(key);
  const messages = history ? JSON.parse(history) : [];
  messages.push({ role: "user", content: state.input.message });
  messages.push({ role: "assistant", content: state.response });
  await redis.set(key, JSON.stringify(messages), "EX", 60 * 60 * 24);
  return {};
}

const graph = new StateGraph<AgentState>()
  .addNode("detectLanguage", detectLanguageNode)
  .addNode("detectIntent", detectIntent)
  .addNode("handleIntent", handleIntent)
  .addNode("translateResponse", translateResponse)
  .addNode("storeMemory", storeMemory)
  .addEdge("detectLanguage", "detectIntent")
  .addEdge("detectIntent", "handleIntent")
  .addEdge("handleIntent", "translateResponse")
  .addEdge("translateResponse", "storeMemory")
  .addEdge("storeMemory", END)
  .setEntryPoint("detectLanguage");

export async function processMessage(input: AgentInput): Promise<AgentOutput> {
  const initialState: AgentState = {
    input,
    toolsUsed: [],
    escalated: false,
  };

  const result = await graph.invoke(initialState);

  return {
    message: result.response || "Sorry, I could not process your request.",
    intent: result.intent || "unknown",
    toolsUsed: result.toolsUsed,
    escalated: result.escalated,
  };
}