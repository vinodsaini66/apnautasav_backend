import { OpenAIEmbeddings } from "@langchain/openai";
import { Chroma } from "@langchain/community/vectorstores/chroma";

let vectorStore: Chroma | null = null;

export async function initVectorStore() {
  vectorStore = await Chroma.fromExistingCollection(
    new OpenAIEmbeddings({ openAIApiKey: process.env.OPENAI_API_KEY }),
    { collectionName: "tour_kb", url: process.env.CHROMA_URL }
  );
}

export async function searchKnowledgeBase(query: string) {
  if (!vectorStore) {
    await initVectorStore();
  }
  return vectorStore!.similaritySearch(query, 4);
}