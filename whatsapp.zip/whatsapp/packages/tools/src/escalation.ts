import { createTicket } from "@db/client";

export async function escalationTool(userId: string, sessionId: string, issue: string) {
  const ticket = await createTicket({ userId, sessionId, issue });
  return `Your issue has been escalated. Ticket ID: ${ticket._id}`;
}