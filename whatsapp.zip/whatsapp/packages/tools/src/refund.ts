import { BookingModel } from "@db/client";

export async function refundTool(bookingId: string) {
  const booking = await BookingModel.findOne({ bookingId });
  if (!booking) return "Booking not found.";
  if (!booking.refundable) return "This booking is not refundable.";
  return "Your refund request has been initiated. You will receive the amount within 7-10 business days.";
}