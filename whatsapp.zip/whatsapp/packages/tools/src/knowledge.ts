import { searchKnowledgeBase } from "@vector-store/client";

export async function knowledgeTool(query: string) {
  const results = await searchKnowledgeBase(query);
  return results.map((r) => r.pageContent).join("\n");
}