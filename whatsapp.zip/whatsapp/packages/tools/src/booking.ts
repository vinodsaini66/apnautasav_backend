import { BookingModel } from "@db/client";

export async function bookingStatusTool(bookingId: string) {
  const booking = await BookingModel.findOne({ bookingId });
  if (!booking) return "Booking not found.";
  return `Your booking status is: ${booking.status}. Package: ${booking.packageName}, Travel Date: ${booking.travelDate}`;
}