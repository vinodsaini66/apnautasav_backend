import { ChatOpenAI } from "@langchain/openai";

const llm = new ChatOpenAI({
  model: "gpt-4o-mini",
  temperature: 0,
  openAIApiKey: process.env.OPENAI_API_KEY,
});

export async function detectLanguage(text: string): Promise<string> {
  const res = await llm.invoke([
    { role: "system", content: "Detect the language of the following text. Respond with only the ISO language code." },
    { role: "user", content: text },
  ]);
  return res.content.trim();
}

export async function translateText(text: string, targetLang: string): Promise<string> {
  const res = await llm.invoke([
    { role: "system", content: `Translate the following text to ${targetLang}.` },
    { role: "user", content: text },
  ]);
  return res.content.trim();
}