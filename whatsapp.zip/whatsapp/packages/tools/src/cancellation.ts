import { BookingModel } from "@db/client";

export async function cancellationTool(bookingId: string) {
  const booking = await BookingModel.findOne({ bookingId });
  if (!booking) return "Booking not found.";
  booking.status = "cancelled";
  await booking.save();
  return "Your booking has been successfully cancelled.";
}