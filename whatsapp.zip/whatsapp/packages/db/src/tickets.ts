import { TicketModel } from "./models/Ticket";

export async function createTicket(data: {
  userId: string;
  sessionId: string;
  issue: string;
}) {
  const ticket = new TicketModel(data);
  return ticket.save();
}

export async function getTickets(userId: string) {
  return TicketModel.find({ userId }).sort({ createdAt: -1 });
}