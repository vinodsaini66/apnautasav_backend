import { Schema, model } from "mongoose";

const ConversationSchema = new Schema(
  {
    userId: { type: String, index: true },
    sessionId: { type: String, index: true },
    channel: { type: String },
    messages: [
      {
        role: { type: String },
        content: { type: String },
        timestamp: { type: Date, default: Date.now },
      },
    ],
    intent: { type: String },
    toolsUsed: [{ type: String }],
    escalated: { type: Boolean, default: false },
    responseTime: { type: Number },
  },
  { timestamps: true }
);

export const ConversationModel = model("Conversation", ConversationSchema);