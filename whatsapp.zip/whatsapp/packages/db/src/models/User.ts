import { Schema, model } from "mongoose";

const UserSchema = new Schema(
  {
    email: { type: String, unique: true },
    phone: { type: String, unique: true },
    name: { type: String },
    language: { type: String, default: "en" },
  },
  { timestamps: true }
);

export const UserModel = model("User", UserSchema);