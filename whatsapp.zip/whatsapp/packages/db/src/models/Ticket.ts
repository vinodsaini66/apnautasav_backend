import { Schema, model } from "mongoose";

const TicketSchema = new Schema(
  {
    userId: { type: String, index: true },
    sessionId: { type: String },
    issue: { type: String },
    status: { type: String, default: "open" },
    assignedTo: { type: String },
  },
  { timestamps: true }
);

export const TicketModel = model("Ticket", TicketSchema);