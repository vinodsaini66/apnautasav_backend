import { Schema, model } from "mongoose";

const FeedbackSchema = new Schema(
  {
    userId: { type: String, index: true },
    sessionId: { type: String },
    rating: { type: Number },
    comment: { type: String },
  },
  { timestamps: true }
);

export const FeedbackModel = model("Feedback", FeedbackSchema);