import { Schema, model } from "mongoose";

const BookingSchema = new Schema(
  {
    bookingId: { type: String, unique: true },
    userId: { type: String, index: true },
    status: { type: String },
    packageName: { type: String },
    travelDate: { type: Date },
    amount: { type: Number },
    refundable: { type: Boolean, default: false },
  },
  { timestamps: true }
);

export const BookingModel = model("Booking", BookingSchema);