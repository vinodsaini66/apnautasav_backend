import Redis from "ioredis";

let redis: Redis | null = null;

export async function initRedis() {
  const url = process.env.REDIS_URL;
  if (!url) throw new Error("REDIS_URL not set");
  redis = new Redis(url);
  console.log("Connected to Redis");
}

export function getRedis() {
  if (!redis) throw new Error("Redis not initialized");
  return redis;
}