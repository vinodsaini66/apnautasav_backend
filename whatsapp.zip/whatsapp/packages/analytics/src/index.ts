import { ConversationModel, FeedbackModel } from "@db/client";

export async function logConversation(data: {
  userId: string;
  sessionId: string;
  channel: string;
  userMessage: string;
  aiResponse: string;
  intent: string;
  toolsUsed: string[];
  escalated: boolean;
  responseTime: number;
}) {
  await ConversationModel.create({
    userId: data.userId,
    sessionId: data.sessionId,
    channel: data.channel,
    messages: [
      { role: "user", content: data.userMessage },
      { role: "assistant", content: data.aiResponse },
    ],
    intent: data.intent,
    toolsUsed: data.toolsUsed,
    escalated: data.escalated,
    responseTime: data.responseTime,
  });
}

export async function saveFeedback(data: {
  userId: string;
  sessionId: string;
  rating: number;
  comment?: string;
}) {
  await FeedbackModel.create(data);
}