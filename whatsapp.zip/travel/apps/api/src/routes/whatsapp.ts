import { Router } from "express";
import { aiApp } from "@repo/ai-core/src/agent";
import { loadMemory, saveMemory } from "@repo/db/src/redis";
import { logConversation } from "@repo/analytics/src/logger";

const router = Router();

router.post("/webhook", async (req, res) => {
  const userMessage = req.body.Body;
  const from = req.body.From;
  const sessionId = `whatsapp:${from}`;

  const memory = await loadMemory(sessionId);

  const result = await aiApp.invoke({
    messages: [...memory, { role: "user", content: userMessage }],
    userId: from,
    sessionId
  });

  const reply = result.messages.at(-1).content;
  await saveMemory(sessionId, result.messages);
  await logConversation(sessionId, result.messages);

  res.set("Content-Type", "text/xml");
  res.send(`<Response><Message>${reply}</Message></Response>`);
});

export default router;
