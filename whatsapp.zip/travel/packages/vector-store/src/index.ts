// import { OpenAIEmbeddings } from "@langchain/openai";
// import { Chroma } from "langchain/vectorstores/chroma";

// const embeddings = new OpenAIEmbeddings();

// export const vectorStore = await Chroma.fromDocuments([], embeddings, {
//   collectionName: "travel_knowledge"
// }); 

import { OpenAIEmbeddings } from "@langchain/openai";
import { Chroma } from "langchain/vectorstores/chroma";

let vectorStore: Chroma | null = null;

export async function getVectorStore() {
  if (!vectorStore) {
    const embeddings = new OpenAIEmbeddings();
    vectorStore = await Chroma.fromExistingCollection(embeddings, {
      collectionName: "travel_knowledge",
    });
  }
  return vectorStore;
}



