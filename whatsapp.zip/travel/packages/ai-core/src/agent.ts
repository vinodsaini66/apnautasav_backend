import { StateGraph } from "@langchain/langgraph";
import { ToolNode } from "@langchain/langgraph/prebuilt";
import { ChatOpenAI } from "@langchain/openai";
import { SYSTEM_PROMPT } from "./prompts";
import { knowledgeTool } from "@repo/tools/src/knowledge.tool";
import { bookingTool } from "@repo/tools/src/booking.tool";
import { ticketTool } from "@repo/tools/src/ticket.tool";
import { languageTool } from "@repo/tools/src/language.tool";
import { z } from "zod";

// ✅ Define state schema
const StateSchema = z.object({
  messages: z.array(z.any()),
  userId: z.string(),
  sessionId: z.string(),
});

type State = z.infer<typeof StateSchema>;

const llm = new ChatOpenAI({
  model: "gpt-4o-mini",
  temperature: 0.2,
});

// ✅ Tools must be StructuredTool / RunnableTool
const tools = [knowledgeTool, bookingTool, ticketTool, languageTool];
const toolNode = new ToolNode<State>(tools);

// ✅ Create graph with schema
export const graph = new StateGraph<State>({
  stateSchema: StateSchema,
});

// ✅ Agent node
graph.addNode("agent", async (state: State) => {
  const response = await llm.invoke(
    [
      { role: "system", content: SYSTEM_PROMPT },
      ...state.messages,
    ],
    { tools }
  );

  return {
    messages: [...state.messages, response],
  };
});

// ✅ Tool node
graph.addNode("tools", toolNode);

// ✅ Edges
graph.addEdge("__start__", "agent");
graph.addEdge("agent", "tools");
graph.addEdge("tools", "agent");

// ✅ Compile
export const aiApp = graph.compile();
